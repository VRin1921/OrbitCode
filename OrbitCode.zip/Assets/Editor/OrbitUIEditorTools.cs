using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace OrbitCode.Editor
{
    public static class OrbitUIEditorTools
    {
        public const string PrefabPath = "Assets/Prefabs/UI/OrbitUI.prefab";
        [MenuItem("Orbit Code/5. Select UI prefab")]
        public static void SelectPrefab()
        {
            Selection.activeObject = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            EditorGUIUtility.PingObject(Selection.activeObject);
        }
        [MenuItem("Orbit Code/6. Validate UI prefab")]
        public static void ValidateUI()
        {
            var root = PrefabUtility.LoadPrefabContents(PrefabPath);
            try
            {
                var ui = root.GetComponent<OrbitUIView>();
                Require(ui != null && root.GetComponent<OrbitApp>() != null, "App/view components");
                Require(root.GetComponent<Canvas>() != null && root.GetComponent<GraphicRaycaster>() != null, "Canvas and raycaster");
                Require(ui.safeArea != null && ui.scroll != null && ui.scroll.viewport != null, "Safe area and scrolling");
                Require(root.GetComponentsInChildren<EventSystem>(true).Length == 1, "One EventSystem");
                var keys = new HashSet<string>();
                foreach (var element in ui.elements)
                {
                    Require(element != null && element.node != null && element.rect != null, "Complete element binding");
                    Require(keys.Add(element.key), "Unique key: " + element.key);
                    if (element.text != null) Require(element.text.font != null, "Font: " + element.key);
                    if (element.button != null)
                    {
                        Require(element.text != null && element.image != null && element.layout != null, "Complete button: " + element.key);
                        Require(element.button.onClick.GetPersistentEventCount() == 0, "No duplicate persistent listeners: " + element.key);
                    }
                }
                var routes = new HashSet<string>();
                int activePanels = 0;
                foreach (var panel in ui.panels)
                {
                    Require(panel.root != null && routes.Add(panel.route), "Unique panel route");
                    Require(panel.root.GetComponent<VerticalLayoutGroup>() != null, "Panel layout: " + panel.route);
                    Require(panel.root.GetComponent<ContentSizeFitter>() != null, "Panel fitter: " + panel.route);
                    if (panel.root.gameObject.activeSelf) activePanels++;
                }
                Require(activePanels == 1 && ui.Get("home.panel").node.activeSelf, "Only Home initially active");
                foreach (string route in new[] { "home", "intro", "map", "theory", "task", "success", "lessonResult", "awards", "summary", "settings", "reset" })
                    Require(routes.Contains(route), "Route: " + route);
                var course = JsonUtility.FromJson<Course>(File.ReadAllText("Assets/Resources/course.json"));
                for (int i = 0; i < course.lessons.Length; i++)
                {
                    ui.Get("map.lesson." + i); ui.Get("awards.lesson." + i); ui.Get("summary.badge." + i);
                    foreach (var task in course.lessons[i].tasks)
                        for (int j = 0; j < task.options.Length; j++)
                        {
                            Require(ui.Get("task.option." + j).button != null, "Answer slot " + j);
                            Require(ui.Get("task.order." + j).button != null, "Order slot " + j);
                        }
                }
                foreach (var transform in root.GetComponentsInChildren<Transform>(true))
                    Require(GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(transform.gameObject) == 0, "No missing script: " + transform.name);
                var app = new SerializedObject(root.GetComponent<OrbitApp>());
                Require(app.FindProperty("ui").objectReferenceValue == ui, "App is wired to view");
                Debug.Log("PASS: UI prefab references, 11 panels, authored answer slots, fonts and components. Next: test both scenes in Play Mode.");
            }
            finally { PrefabUtility.UnloadPrefabContents(root); }
        }
        [MenuItem("Orbit Code/7. Add UI prefab to current scene")]
        public static void AddToScene()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Exit Play Mode first.");
            if (UnityEngine.Object.FindFirstObjectByType<OrbitApp>(FindObjectsInactive.Include) != null)
                throw new InvalidOperationException("This scene already has OrbitApp. Do not add a second UI/app. Use the existing prefab or remove the old app deliberately first.");
            if (UnityEngine.Object.FindFirstObjectByType<EventSystem>(FindObjectsInactive.Include) != null)
                throw new InvalidOperationException("The UI prefab already includes EventSystem. Remove the scene's existing EventSystem deliberately first, or remove the prefab's EventSystem in a variant.");
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
            if (prefab == null) throw new InvalidOperationException("Missing " + PrefabPath);
            var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab, UnityEngine.SceneManagement.SceneManager.GetActiveScene());
            Undo.RegisterCreatedObjectUndo(instance, "Add Orbit UI");
            EditorSceneManager.MarkSceneDirty(instance.scene); Selection.activeGameObject = instance;
        }
        [MenuItem("Orbit Code/8. Export UI unitypackage")]
        public static void ExportPackage()
        {
            ValidateUI();
            string path = EditorUtility.SaveFilePanel("Export Orbit UI", "", "OrbitCode-StaticUI", "unitypackage");
            if (string.IsNullOrEmpty(path)) return;
            AssetDatabase.ExportPackage(new[] {
                "Assets/Prefabs", "Assets/UI", "Assets/Scripts", "Assets/Resources",
                "Assets/Editor", "Assets/Scenes/Main.unity", "Assets/OrbitCode.unity"
            }, path, ExportPackageOptions.Recurse | ExportPackageOptions.IncludeDependencies);
            Debug.Log("UI package exported: " + path);
        }
        static void Require(bool condition, string message)
        {
            if (!condition) throw new InvalidOperationException("Orbit UI validation failed: " + message);
        }
    }
}
