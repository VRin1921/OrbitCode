using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace OrbitCode.Editor
{
    [InitializeOnLoad]
    public static class ProjectTools
    {
        const string Scene = "Assets/Scenes/Main.unity";
        static ProjectTools()
        {
            EditorApplication.delayCall += () => {
                if (EditorApplication.isPlayingOrWillChangePlaymode) return;
                if (EditorBuildSettings.scenes.Length == 0) Configure();
            };
        }
        [MenuItem("Orbit Code/1. Configure project")]
        public static void Configure()
        {
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(Scene, true) };
            PlayerSettings.companyName = "OrbitCodeTeam";
            PlayerSettings.productName = "Орбита кода";
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.SetApplicationIdentifier(UnityEditor.Build.NamedBuildTarget.Android, "com.orbitcodeteam.orbitcode");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.defaultScreenWidth = 480; PlayerSettings.defaultScreenHeight = 900;
            // This project uses StandaloneInputModule and has no dependency on the new Input System.
            var playerAssets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
            if (playerAssets.Length > 0)
            {
                var serialized = new SerializedObject(playerAssets);
                var input = serialized.FindProperty("activeInputHandler");
                if (input != null) { input.intValue = 0; serialized.ApplyModifiedProperties(); }
            }
            AssetDatabase.SaveAssets();
            Debug.Log("Orbit Code configured. Open Assets/Scenes/Main.unity and press Play. Use portrait Game view 480x900.");
        }
        [MenuItem("Orbit Code/2. Open main scene")]
        public static void OpenScene() { UnityEditor.SceneManagement.EditorSceneManager.OpenScene(Scene); }
        [MenuItem("Orbit Code/3. Check course and progress")]
        public static void CheckCourse()
        {
            var c = JsonUtility.FromJson<Course>(File.ReadAllText("Assets/Resources/course.json"));
            Assert(c.lessons.Length >= 3, "At least 3 lessons");
            var p = Progress.Fresh(c);
            Assert(!p.Unlocked(c, 1), "Second lesson initially locked");
            bool ordering = false, choice = false;
            for (int i = 0; i < c.lessons.Length; i++)
            {
                Assert(p.Unlocked(c, i), "Lesson unlocked sequentially");
                var l = c.lessons[i];
                Assert(!string.IsNullOrEmpty(l.theory) && !string.IsNullOrEmpty(l.example), "Lesson explanation and example");
                for (int j = 0; j < l.tasks.Length; j++)
                {
                    var t = l.tasks[j]; Assert(!string.IsNullOrEmpty(t.hint) && !string.IsNullOrEmpty(t.explanation), "Hint and explanation");
                    if (t.kind == "order")
                    {
                        ordering = true;
                        Assert(t.correctOrder.Length == t.options.Length, "Order length");
                        var unique = new System.Collections.Generic.HashSet<int>(t.correctOrder);
                        Assert(unique.Count == t.options.Length, "Order is a permutation");
                        foreach (int k in t.correctOrder) Assert(k >= 0 && k < t.options.Length, "Order index in bounds");
                        Assert(t.Check(-1, t.correctOrder), "Correct order accepted");
                        var wrong = (int[])t.correctOrder.Clone(); int swap = wrong[0]; wrong[0] = wrong[1]; wrong[1] = swap;
                        Assert(!t.Check(-1, wrong), "Wrong order rejected");
                        Assert(!t.Check(-1, new int[0]), "Empty order rejected");
                    }
                    else
                    {
                        choice = true; Assert(t.answer >= 0 && t.answer < t.options.Length, "Answer in bounds");
                        Assert(t.Check(t.answer, null), "Correct choice accepted"); Assert(!t.Check(-1, null), "No choice rejected");
                        Assert(!t.Check((t.answer + 1) % t.options.Length, null), "Wrong choice rejected");
                    }
                    Assert(p.Award(c, i, j), "First success awards XP");
                    Assert(!p.Award(c, i, j), "Replay cannot farm XP");
                }
                Assert(p.LessonDone(c, i), "Lesson complete");
            }
            Assert(ordering && choice, "Two formats"); Assert(p.Xp == c.TaskCount * 50, "XP total");
            Assert(p.Completed(c) == c.lessons.Length, "Module completed");
            var roundtrip = JsonUtility.FromJson<Progress>(JsonUtility.ToJson(p));
            Assert(roundtrip.Xp == p.Xp && roundtrip.Completed(c) == c.lessons.Length, "Save serialization roundtrip");
            Debug.Log("PASS: course, checks, sequential unlocks, XP deduplication and save serialization. This is not a visual or device test.");
        }
        static void Assert(bool value, string message) { if (!value) throw new InvalidOperationException("FAIL: " + message); }
        [MenuItem("Orbit Code/4. Build Android APK")]
        public static void BuildAndroid()
        {
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
                throw new InvalidOperationException("Install Android Build Support, SDK, NDK and OpenJDK through Unity Hub.");
            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
                throw new InvalidOperationException("Could not switch to Android. Check Console.");
            Configure(); CheckCourse(); OrbitUIEditorTools.ValidateUI();
            PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            EditorUserBuildSettings.buildAppBundle = false;
            Directory.CreateDirectory("Builds");
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions { scenes = new[] { Scene }, locationPathName = "Builds/OrbitCode.apk", target = BuildTarget.Android, options = BuildOptions.None });
            if (report.summary.result != BuildResult.Succeeded) throw new InvalidOperationException("Android build failed. Check Console.");
            Debug.Log("Built: Builds/OrbitCode.apk");
        }
    }
}
