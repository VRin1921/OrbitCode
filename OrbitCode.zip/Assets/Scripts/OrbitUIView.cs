using System;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace OrbitCode
{
    public sealed class OrbitUIView : MonoBehaviour
    {
        [Serializable] public sealed class Element
        {
            public string key;
            public GameObject node;
            public Text text;
            public Button button;
            public Image image;
            public RectTransform rect;
            public LayoutElement layout;
        }
        [Serializable] public sealed class Panel
        {
            public string route;
            public RectTransform root;
        }
        public RectTransform safeArea;
        public ScrollRect scroll;
        public Panel[] panels;
        public Element[] elements;
        public Color primaryColor = new Color(0.1411765f, 0.3607843f, 0.8392157f);
        public Color secondaryColor = new Color(0.9294118f, 0.9529412f, 1f);
        public Color primaryTextColor = Color.white;
        public Color secondaryTextColor = new Color(0.1411765f, 0.3607843f, 0.8392157f);

        public bool animate = true;
        [Range(0.1f, 1f)] public float enterDuration = 0.18f;
        readonly Dictionary<string, Element> lookup = new Dictionary<string, Element>();
        RectTransform current;
        Rect lastSafe;
        int lastWidth, lastHeight;
        float previousScroll = 1f;
        bool entering;
        const string EnterId = "orbit.enter", PressId = "orbit.press", PopId = "orbit.pop", ShakeId = "orbit.shake", BarId = "orbit.bar";

        void Awake() { BuildLookup(); ApplySafeArea(); }
        void BuildLookup()
        {
            if (lookup.Count > 0 || elements == null) return;
            foreach (var e in elements)
            {
                if (e == null || string.IsNullOrEmpty(e.key) || e.node == null)
                    throw new InvalidOperationException("Orbit UI: incomplete binding.");
                if (lookup.ContainsKey(e.key)) throw new InvalidOperationException("Duplicate Orbit UI key: " + e.key);
                lookup.Add(e.key, e);
            }
        }
        public Element Get(string key)
        {
            BuildLookup();
            if (!lookup.TryGetValue(key, out var element))
                throw new InvalidOperationException("Missing Orbit UI binding: " + key);
            return element;
        }
        public void SetText(string key, string value) { Get(key).text.text = value ?? ""; }
        public void Visible(string key, bool visible)
        {
            var e = Get(key);
            bool wasVisible = e.node.activeSelf;
            e.node.SetActive(visible);
            if (visible && !wasVisible && !entering) PopRect(e.rect, 0f);
        }
        public void SetButton(string key, string title, Action clicked, bool primary = false, bool interactable = true)
        {
            var e = Get(key);
            if (title != null) e.text.text = title;
            e.button.interactable = interactable;
            TweenColor(e.image, primary ? primaryColor : secondaryColor);
            TweenColor(e.text, primary ? primaryTextColor : secondaryTextColor);
            e.button.onClick.RemoveAllListeners();
            if (clicked != null) e.button.onClick.AddListener(() => { Press(e.rect); clicked(); });
        }
        public void Bind(string key, Action clicked)
        {
            var e = Get(key);
            e.button.onClick.RemoveAllListeners();
            e.button.onClick.AddListener(() => { Press(e.rect); clicked(); });
        }
        public void ProgressBar(string key, float value)
        {
            var r = Get(key).rect;
            float target = Mathf.Clamp01(value);
            DOTween.Kill(r, BarId, false);
            if (!animate || Mathf.Abs(r.anchorMax.x - target) < 0.001f) { r.anchorMax = new Vector2(target, 1); return; }
            DOTween.To(() => r.anchorMax.x, x => r.anchorMax = new Vector2(x, 1), target, 0.35f)
                .SetEase(Ease.OutCubic).SetDelay(entering ? 0.08f : 0f).SetTarget(r).SetId(BarId);
        }
        public void Activate(string route)
        {
            previousScroll = scroll.verticalNormalizedPosition;
            RectTransform target = null;
            foreach (var panel in panels) if (panel.route == route) target = panel.root;
            if (target == null) throw new InvalidOperationException("Missing Orbit UI panel: " + route);
            scroll.StopMovement();
            if (target != current) { entering = true; CompleteEnter(target); }
            foreach (var panel in panels) panel.root.gameObject.SetActive(panel.root == target);
            current = target;
            scroll.content = current;
            if (EventSystem.current != null) EventSystem.current.SetSelectedGameObject(null);
        }
        public void Refresh(bool keepScroll = false)
        {
            if (current == null) return;
            Canvas.ForceUpdateCanvases();
            LayoutRebuilder.ForceRebuildLayoutImmediate(current);

            foreach (var e in elements)
            {
                if (e.button == null || e.layout == null || !e.node.activeInHierarchy) continue;
                var textRect = (RectTransform)e.text.transform;
                float width = Mathf.Max(1f, textRect.rect.width);
                var settings = e.text.GetGenerationSettings(new Vector2(width, 0));
                float height = e.text.cachedTextGeneratorForLayout.GetPreferredHeight(e.text.text, settings) / e.text.pixelsPerUnit;
                e.layout.preferredHeight = Mathf.Max(e.layout.minHeight, height + 28);
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(current);
            Canvas.ForceUpdateCanvases();
            scroll.verticalNormalizedPosition = keepScroll ? previousScroll : 1f;
            if (entering) { entering = false; PlayEnter(current); }
        }
        void Update()
        {
            if (lastSafe == Screen.safeArea && lastWidth == Screen.width && lastHeight == Screen.height) return;
            float position = scroll != null ? scroll.verticalNormalizedPosition : 1f;
            ApplySafeArea();
            CompleteEnter(current);
            previousScroll = position;
            Refresh(true);
        }
        public void Pop(string key, float delay = 0f) { PopRect(Get(key).rect, delay); }
        public void Shake(string key)
        {
            var r = Get(key).rect;
            if (!animate || r == null) return;
            DOTween.Kill(r, ShakeId, true);
            r.DOPunchAnchorPos(new Vector2(10f, 0f), 0.25f, 12, 0.5f).SetId(ShakeId);
        }
        void PopRect(RectTransform r, float delay)
        {
            if (!animate || r == null) return;
            DOTween.Kill(r, PressId, true); DOTween.Kill(r, PopId, true);
            r.localScale = Vector3.one * 0.92f;
            r.DOScale(1f, 0.18f).SetDelay(delay).SetEase(Ease.OutBack).SetId(PopId);
        }
        void Press(RectTransform r)
        {
            if (!animate || r == null) return;
            DOTween.Kill(r, PressId, true);
            r.localScale = Vector3.one;
            r.DOScale(0.95f, 0.06f).SetLoops(2, LoopType.Yoyo).SetEase(Ease.OutQuad).SetId(PressId);
        }
        void TweenColor(Graphic g, Color color)
        {
            g.DOKill();
            if (!animate || entering || g.color == color || !g.gameObject.activeInHierarchy) { g.color = color; return; }
            g.DOColor(color, 0.12f);
        }
        void PlayEnter(RectTransform panel)
        {
            var group = panel.GetComponent<CanvasGroup>();
            if (!animate) { if (group != null) group.alpha = 1f; return; }
            if (group == null) group = panel.gameObject.AddComponent<CanvasGroup>(); 

            group.DOKill(); group.alpha = 0f;
            group.DOFade(1f, enterDuration * 0.8f).SetEase(Ease.OutQuad);
            int n = 0;
            for (int i = 0; i < panel.childCount; i++)
            {
                var child = panel.GetChild(i) as RectTransform;
                if (child == null || !child.gameObject.activeSelf) continue;
                Vector2 end = child.anchoredPosition;
                child.anchoredPosition = end + new Vector2(0f, -16f);
                child.DOAnchorPos(end, enterDuration).SetDelay(Mathf.Min(n++ * 0.03f, 0.12f)).SetEase(Ease.OutCubic).SetId(EnterId);
            }
        }
        void CompleteEnter(RectTransform panel)
        {
            if (panel == null) return;

            for (int i = 0; i < panel.childCount; i++) DOTween.Kill(panel.GetChild(i), EnterId, true);
            var group = panel.GetComponent<CanvasGroup>();
            if (group != null) { group.DOKill(); group.alpha = 1f; }
        }
        void ApplySafeArea()
        { 
            if (safeArea == null || Screen.width <= 0 || Screen.height <= 0) return;
            lastSafe = Screen.safeArea; lastWidth = Screen.width; lastHeight = Screen.height;
            safeArea.anchorMin = new Vector2(lastSafe.xMin / Screen.width, lastSafe.yMin / Screen.height);
            safeArea.anchorMax = new Vector2(lastSafe.xMax / Screen.width, lastSafe.yMax / Screen.height);
            safeArea.offsetMin = safeArea.offsetMax = Vector2.zero;
        }
    }
}
