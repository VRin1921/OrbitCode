using System;
using System.Collections.Generic;
using UnityEngine;

namespace OrbitCode
{
    [Serializable] public class Course
    {
        public string title;
        public string teamName = "INdeLL";
        public Lesson[] lessons;
        public int TaskCount { get { int n = 0; foreach (var l in lessons) n += l.tasks.Length; return n; } }
    }
    [Serializable] public class Lesson
    {
        public string title, subtitle, goal, theory, example, takeaway, badge;
        public Exercise[] tasks;
    }
    [Serializable] public class Exercise
    {
        public string kind, title, prompt, code, hint, explanation;
        public string[] options;
        public int answer;
        public int[] correctOrder;
        public bool Check(int selected, IList<int> order)
        {
            if (kind != "order") return selected == answer;
            if (order == null || correctOrder == null || order.Count != correctOrder.Length) return false;
            for (int i = 0; i < order.Count; i++) if (order[i] != correctOrder[i]) return false;
            return true;
        }
    }
    [Serializable] public class Progress
    {
        public int version = 1;
        public bool introSeen;
        public bool[] solved;
        public static Progress Fresh(Course c) { return new Progress { solved = new bool[c.TaskCount] }; }
        public int SolvedCount { get { int n = 0; foreach (bool s in solved) if (s) n++; return n; } }
        public int Xp { get { return SolvedCount * 50; } }
        public int Offset(Course c, int lesson) { int n = 0; for (int i = 0; i < lesson; i++) n += c.lessons[i].tasks.Length; return n; }
        public bool LessonDone(Course c, int lesson)
        {
            int k = Offset(c, lesson);
            for (int i = 0; i < c.lessons[lesson].tasks.Length; i++) if (!solved[k + i]) return false;
            return true;
        }
        public int Completed(Course c) { int n = 0; for (int i = 0; i < c.lessons.Length; i++) if (LessonDone(c, i)) n++; return n; }
        public bool Unlocked(Course c, int lesson) { return lesson == 0 || LessonDone(c, lesson - 1); }
        public bool Award(Course c, int lesson, int task)
        {
            int k = Offset(c, lesson) + task;
            if (solved[k]) return false;
            solved[k] = true;
            return true;
        }
    }
    public static class ProgressStore
    {
        const string Key = "OrbitCode.progress.v1";
        public static Progress Load(Course c)
        {
            try
            {
                var p = JsonUtility.FromJson<Progress>(PlayerPrefs.GetString(Key, ""));
                if (p != null && p.version == 1 && p.solved != null && p.solved.Length == c.TaskCount)
                {
                    bool previousDone = true;
                    for (int i = 0; i < c.lessons.Length; i++)
                    {
                        if (!previousDone) for (int j = 0; j < c.lessons[i].tasks.Length; j++) p.solved[p.Offset(c, i) + j] = false;
                        previousDone = p.LessonDone(c, i);
                    }
                    return p;
                }
            }
            catch (Exception e) { Debug.LogWarning("Progress reset: " + e.Message); }
            return Progress.Fresh(c);
        }
        public static void Save(Progress p) { PlayerPrefs.SetString(Key, JsonUtility.ToJson(p)); PlayerPrefs.Save(); }
        public static void Reset() { PlayerPrefs.DeleteKey(Key); PlayerPrefs.Save(); }
    }
}
