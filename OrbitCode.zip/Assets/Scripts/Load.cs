using UnityEngine;
using System.Collections.Generic;
using System;

public class Load : MonoBehaviour
{
    public GameObject UI;
    void Start() => UI.SetActive(true);
}
