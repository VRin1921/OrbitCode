using System;
using System.Collections.Generic;
using UnityEngine;

namespace OrbitCode
{
    public sealed class OrbitApp : MonoBehaviour
    {
        [SerializeField] OrbitUIView ui;
        Course course;
        Progress progress;
        int lessonIndex, taskIndex, selected = -1;
        readonly List<int> order = new List<int>();
        bool hintShown;
        string feedback = "", route = "home";
        int shownXp = -1;
        const string CapacityMessage = "Orbit UI slots are too small. Add authored slots and bindings in OrbitUI.prefab.";
        float Fraction { get { return (float)progress.SolvedCount / course.TaskCount; } }
        void Awake()
        {
            if (ui == null) { Debug.LogError("Assign OrbitUIView, or use the prepared OrbitUI prefab.", this); enabled = false; return; }
            var json = Resources.Load<TextAsset>("course");
            if (json == null) { Debug.LogError("Missing Resources/course.json.", this); enabled = false; return; }
            course = JsonUtility.FromJson<Course>(json.text);
            if (course == null || course.lessons == null || course.lessons.Length < 3 || course.TaskCount == 0)
            { Debug.LogError("Invalid course.", this); enabled = false; return; }

            try
            {
                for (int i = 0; i < course.lessons.Length; i++)
                {
                    ui.Get("map.lesson." + i); ui.Get("awards.lesson." + i); ui.Get("summary.badge." + i);
                    foreach (var task in course.lessons[i].tasks)
                        for (int j = 0; j < task.options.Length; j++) { ui.Get("task.option." + j); ui.Get("task.order." + j); }
                }
            }
            catch (InvalidOperationException e) { Debug.LogError(CapacityMessage + " " + e.Message, this); enabled = false; return; }
            progress = ProgressStore.Load(course);
            Application.targetFrameRate = 60; Screen.orientation = ScreenOrientation.Portrait;
            ui.SetText("shell.footer", "Команда: INdeLL");
            BindNavigation(); Home();
        }
        void BindNavigation()
        {
            ui.Bind("home.start", () => { if (progress.introSeen) Map(); else Intro(); });
            ui.Bind("home.intro", Intro); ui.Bind("home.settings", Settings);
            ui.Bind("intro.map", () => { progress.introSeen = true; ProgressStore.Save(progress); Map(); });
            ui.Bind("intro.home", Home);
            ui.Bind("map.summary", Summary); ui.Bind("map.awards", Awards); ui.Bind("map.home", Home);
            ui.Bind("theory.practice", BeginTask); ui.Bind("theory.map", Map);
            ui.Bind("task.clear", () => { order.Clear(); feedback = ""; TaskScreen(true); });
            ui.Bind("task.check", Check);
            ui.Bind("task.hintToggle", () => { hintShown = !hintShown; TaskScreen(true); });
            ui.Bind("task.theory", Theory); ui.Bind("task.map", Map);
            ui.Bind("success.next", () => {
                if (taskIndex + 1 < course.lessons[lessonIndex].tasks.Length) { taskIndex++; BeginTask(); }
                else LessonResult();
            });
            ui.Bind("success.repeat", BeginTask); ui.Bind("success.map", Map);
            ui.Bind("lessonResult.next", () => { if (lessonIndex + 1 < course.lessons.Length) OpenLesson(lessonIndex + 1); else Summary(); });
            ui.Bind("lessonResult.repeat", () => { taskIndex = 0; Theory(); }); ui.Bind("lessonResult.map", Map);
            ui.Bind("awards.map", Map); ui.Bind("summary.map", Map); ui.Bind("summary.home", Home);
            ui.Bind("settings.reset", ConfirmReset); ui.Bind("settings.home", Home);
            ui.Bind("reset.confirm", () => { ProgressStore.Reset(); progress = Progress.Fresh(course); Home(); });
            ui.Bind("reset.cancel", Settings);
        }
        void Update()
        {
#if ENABLE_LEGACY_INPUT_MANAGER
            if (Input.GetKeyDown(KeyCode.Escape)) Back();
#endif
        }
        void OnApplicationPause(bool paused) { if (paused && progress != null) ProgressStore.Save(progress); }
        void OnApplicationQuit() { if (progress != null) ProgressStore.Save(progress); }
        void Render(string screen, Action update, bool keepScroll = false)
        {
            route = screen; ui.Activate(screen);
            ui.SetText("shell.xp", progress.Xp + " XP");
            if (shownXp >= 0 && shownXp != progress.Xp) ui.Pop("shell.xp", 0.1f);
            shownXp = progress.Xp;
            update(); ui.Refresh(keepScroll);
        }
        void Home()
        {
            Render("home", () => {
                ui.SetText("home.title", course.title);
                ui.SetText("home.start", progress.SolvedCount > 0 ? "Продолжить обучение" : "Начать обучение");
                ui.SetText("home.count", course.lessons.Length + " урока  •  " + course.TaskCount + " заданий");
                ui.Visible("home.progress", progress.SolvedCount > 0); ui.Visible("home.solved", progress.SolvedCount > 0);
                ui.ProgressBar("home.progress.fill", Fraction);
                ui.SetText("home.solved", "Решено: " + progress.SolvedCount + " из " + course.TaskCount);
            });
        }
        void Intro() { Render("intro", () => { }); }
        void Map()
        {
            Render("map", () => {
                ui.SetText("map.completed", "Уроки: " + progress.Completed(course) + "/" + course.lessons.Length + "  •  Осталось: " + (course.lessons.Length - progress.Completed(course)));
                ui.ProgressBar("map.progress.fill", Fraction);
                ui.SetText("map.solved", "Задания: " + progress.SolvedCount + "/" + course.TaskCount + "  •  " + Mathf.RoundToInt(100f * Fraction) + "%");
                for (int i = 0; i < course.lessons.Length; i++)
                {
                    int id = i; var l = course.lessons[i]; var k = "map.lesson." + i;
                    bool done = progress.LessonDone(course, i), unlocked = progress.Unlocked(course, i);
                    ui.SetText(k + ".subtitle", l.subtitle); ui.SetText(k + ".title", l.title); ui.SetText(k + ".goal", l.goal);
                    ui.SetText(k + ".status", done ? "Пройдено / Значок: " + l.badge : unlocked ? "Доступно / " + l.tasks.Length + " задания / до " + l.tasks.Length * 50 + " XP" : "Закрыто / Заверши предыдущий урок");
                    ui.SetButton(k + ".open", done ? "Повторить урок" : unlocked ? "Открыть урок" : "Пока закрыто", () => OpenLesson(id), !done && unlocked, unlocked);
                }
                ui.Visible("map.summary", progress.Completed(course) == course.lessons.Length);
            });
        }
        void OpenLesson(int index)
        {
            if (index < 0 || index >= course.lessons.Length || !progress.Unlocked(course, index)) return;
            lessonIndex = index; taskIndex = 0;
            if (!progress.LessonDone(course, index))
                while (taskIndex < course.lessons[index].tasks.Length - 1 && progress.solved[progress.Offset(course, index) + taskIndex]) taskIndex++;
            Theory();
        }
        void Theory()
        {
            var l = course.lessons[lessonIndex];
            Render("theory", () => {
                ui.SetText("theory.eyebrow", "Урок " + (lessonIndex + 1) + " из " + course.lessons.Length + " / Теория");
                ui.SetText("theory.title", l.title); ui.SetText("theory.goal", l.goal);
                ui.SetText("theory.body", l.theory); ui.SetText("theory.example", l.example);
            });
        }
        void BeginTask() { selected = -1; order.Clear(); hintShown = false; feedback = ""; TaskScreen(); }
        Exercise Current { get { return course.lessons[lessonIndex].tasks[taskIndex]; } }
        void TaskScreen(bool keep = false)
        {
            var e = Current;
            Render("task", () => {
                ui.SetText("task.eyebrow", "Урок " + (lessonIndex + 1) + "/" + course.lessons.Length + " / Задание " + (taskIndex + 1) + "/" + course.lessons[lessonIndex].tasks.Length);
                ui.SetText("task.title", e.title); ui.SetText("task.prompt", e.prompt);
                ui.SetText("task.kind", e.kind == "order" ? "СОБЕРИ ПОСЛЕДОВАТЕЛЬНОСТЬ" : e.kind == "bug" ? "НАЙДИ ОШИБКУ" : "ВЫБЕРИ ОТВЕТ");
                ui.SetText("task.code", e.code);
                bool ordering = e.kind == "order";
                ui.Visible("task.orderCard", ordering); ui.Visible("task.available", ordering);
                ui.SetText("task.orderCount", "Твой алгоритм: " + order.Count + "/" + e.options.Length);
                ui.Visible("task.empty", order.Count == 0);

                int slots = 0;
                foreach (var element in ui.elements)
                    if (element.button != null && element.key.StartsWith("task.option.", StringComparison.Ordinal)) slots++;
                for (int i = 0; i < slots; i++)
                {
                    string optionKey = "task.option." + i, orderKey = "task.order." + i;
                    bool hasOption = i < e.options.Length;
                    ui.Visible(optionKey, hasOption && (!ordering || !order.Contains(i)));
                    ui.Visible(orderKey, ordering && i < order.Count);
                    if (hasOption)
                    {
                        int id = i;
                        ui.SetButton(optionKey, (ordering ? "+  " : selected == i ? "●  " : "○  ") + e.options[i], () => {
                            if (ordering) order.Add(id); else selected = id;
                            feedback = ""; TaskScreen(true);
                        }, !ordering && selected == i);
                    }
                    if (ordering && i < order.Count)
                    {
                        int pos = i;
                        ui.SetButton(orderKey, (i + 1) + ". " + e.options[order[i]] + "  ×", () => { order.RemoveAt(pos); feedback = ""; TaskScreen(true); });
                    }
                }
                ui.Visible("task.clear", ordering && order.Count > 0);
                ui.Visible("task.feedbackCard", !string.IsNullOrEmpty(feedback)); ui.SetText("task.feedback", feedback);
                ui.Visible("task.hintCard", hintShown); ui.SetText("task.hint", e.hint);
                ui.Get("task.check").button.interactable = ordering ? order.Count == e.options.Length : selected >= 0;
                ui.SetText("task.hintToggle", hintShown ? "Скрыть подсказку" : "Получить подсказку");
            }, keep);
        }
        void Check()
        {
            var e = Current;
            if (!e.Check(selected, order))
            {
                feedback = e.kind == "order" ? "Порядок пока не ведёт к цели. Удали неверный шаг нажатием, собери команды заново и нажми «Проверить ответ»." : "Сравни выбранный ответ с целью. Выбери другой вариант и проверь ещё раз. Подсказка поможет найти следующий шаг.";
                TaskScreen(); ui.Shake("task.feedbackCard"); return;
            }
            bool awarded = progress.Award(course, lessonIndex, taskIndex); ProgressStore.Save(progress);
            Render("success", () => {
                ui.SetText("success.reward", awarded ? "+50 XP / Сигнал усилен" : "Повторение закрепляет навык");
                ui.SetText("success.explanation", e.explanation);
                ui.SetText("success.total", "Всего: " + progress.Xp + " XP  •  Решено: " + progress.SolvedCount + "/" + course.TaskCount);
                ui.ProgressBar("success.progress.fill", Fraction); ui.Visible("success.replayNote", !awarded);
                ui.SetText("success.next", taskIndex + 1 < course.lessons[lessonIndex].tasks.Length ? "Следующее задание" : "Завершить урок");
            });
            ui.Pop("success.reward", 0.08f);
        }
        void LessonResult()
        {
            var l = course.lessons[lessonIndex];
            Render("lessonResult", () => {
                ui.SetText("lessonResult.eyebrow", "Урок " + (lessonIndex + 1) + " завершён");
                ui.SetText("lessonResult.badge", l.badge); ui.SetText("lessonResult.takeaway", l.takeaway);
                ui.SetText("lessonResult.completed", "Пройдено уроков: " + progress.Completed(course) + "/" + course.lessons.Length);
                ui.ProgressBar("lessonResult.progress.fill", Fraction);
                bool next = lessonIndex + 1 < course.lessons.Length;
                ui.SetText("lessonResult.next", next ? "Открыть следующий урок" : "Итоги миссии");
                ui.Get("lessonResult.next").button.interactable = !next || progress.Unlocked(course, lessonIndex + 1);
            });
            ui.Pop("lessonResult.badge", 0.08f);
        }
        void Awards()
        {
            Render("awards", () => {
                ui.SetText("awards.xp", progress.Xp + " из " + course.TaskCount * 50 + " XP");
                for (int i = 0; i < course.lessons.Length; i++)
                {
                    string k = "awards.lesson." + i; bool done = progress.LessonDone(course, i);
                    ui.SetText(k + ".badge", course.lessons[i].badge);
                    ui.Get(k + ".badge").text.color = done ? ui.primaryColor : new Color(0.3254902f, 0.3921569f, 0.4823529f);
                    ui.SetText(k + ".status", done ? "Получен / Урок " + (i + 1) + " пройден" : "Заверши урок " + (i + 1) + ", чтобы получить значок");
                }
            });
        }
        void Summary()
        {
            if (progress.Completed(course) != course.lessons.Length) { Map(); return; }
            Render("summary", () => {
                ui.SetText("summary.completed", course.lessons.Length + " / " + course.lessons.Length + " УРОКА");
                ui.SetText("summary.xp", progress.Xp + " XP");
                for (int i = 0; i < course.lessons.Length; i++) ui.SetText("summary.badge." + i, "• " + course.lessons[i].badge);
            });
            ui.Pop("summary.xp", 0.08f);
        }
        void Settings() { Render("settings", () => { }); }
        void ConfirmReset() { Render("reset", () => { }); }
        void Back()
        {
            if (route == "home") return;
            if (route == "task") { Theory(); return; }
            if (route == "reset") { Settings(); return; }
            if (route == "map" || route == "intro" || route == "settings") Home(); else Map();
        }
    }
}
